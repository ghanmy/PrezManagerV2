<?
if(isset($_POST['time'])){

	$time = $_POST['time'];

	$to = "rahali.dali@gmail.com";
	// $to = "miro19k@gmail.com";

	$subject = "Tracktime de Celiprol Adwya";
  	$headers = "From: Celiprol Adwya Présentation<no-replay@applications-mobile.ch>\r\n";
  	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=UTF-8";

	$body = "Suite à la visite de votre dérogataire, veuillez trouver le temps passé sur chaque page<br><br>";
	for ($i=0; $i < count($time)-1; $i++) { 
		if($time[$i]<60)
			$body .= "Page".($i+1)." : ".round($time[$i])." secondes <br>";
		else
			$body .= "Page".($i+1)." : ".round($time[$i]/60)." minutes et ".round($time[$i]%60)." secondes <br>";
	}

	if (mail($to, $subject, $body,$headers)) {
		echo("done");
	} else {
		echo("error");
	}

}
