
    window.addEventListener('impress:stepenter', function() {
       
        switch(window.location.hash){
            case"#/intro":
                    $("#intro .logo").removeClass("flipInX animated");
                    $("#intro .logo").addClass("flipInX animated");

                    $("#intro .box").removeClass("fadeInLeft animated");
                    $("#intro .box").addClass("fadeInLeft animated");

            break;



            case "#/blockview":
            case "#/chart1":
            case "#/chart2":

                                $('#container1').highcharts({

                            chart:{
                                backgroundColor: null,
                            },

                            plotOptions: {
                                series: {
                                    connectNulls: true
                                }
                            },

                            title: {
                                text: 'Variation du score MADRS total à la 8ème semaine(1)',
                                x: -20 //center
                            },
                            subtitle: {
                                text: 'Etude randomisé en double aveugle, durée 8 semaines,<br>n= 471 patients randomisés.<br>Le bras citalopram n=160 (molécule non commercialisée en Tunisie) n’est pas représentée sur le graphe.<br> -14,1 à 8 semaine en LOCF.',
                                align:'center',
                                verticalAlign: 'bottom',
                                y: 15,
                                useHTML:true
                            },
                            xAxis: {
                                categories: ['0','1','2','3','4','5','6','7','8']
                            },
                            yAxis: {
                                title: {
                                    text: 'Variation moyenne du score MADRS total <br> par rapport à l’inclusion (OC)'
                                },
                                plotLines: [{
                                    value: 0,
                                    width: 1,
                                    color: '#808080'
                                }]
                            },
                            // tooltip: {
                            //     valueSuffix: '°C'
                            // },
                            legend: {
                                layout: 'vertical',
                                align: 'right',
                                verticalAlign: 'middle',
                                borderWidth: 0
                            },
                            series: [{
                                name: 'Placebo (n=154)',
                                data: [0,-3.5,-7.5,-9,-9,null,-12,null,-13.5]
                            }, 
                             {
                                name: 'Seroplex® 10-20 mg/jour <br>(n=155)',
                                data: [0,-4.5,-9,-11,-12,null,-14,null,-16]
                            }
                            ]
                        });
                    
                        $("#container1 .highcharts-container").css("height","500px");
                        


   $('#container2').highcharts({

                            chart:{
                                backgroundColor: null,
                            },

                            plotOptions: {
                                series: {
                                    connectNulls: true
                                }
                            },

                            title: {
                                text: "Evolution de l'item  « tension intérieure »  <br> sous citalopram et Escitalopram",
                                x: -20 //center
                            },
                            subtitle: {
                                text: "les résultat à l'item Tension intérieure de la MADRS sont représentée par visite,<br> avec les valeurs finales selo le principe LOCF",
                                align:'center',
                                verticalAlign: 'bottom',
                                y: 15,
                                useHTML:true
                            },
                            xAxis: {
                                categories: ['0','1','2','3','4','5','6','7','8']
                            },
                            yAxis: {
                                title: {
                                    text: 'Variation par rapport au score initial'
                                },
                                plotLines: [{
                                    value: 0,
                                    width: 1,
                                    color: '#808080'
                                }]
                            },
                            // tooltip: {
                            //     valueSuffix: '°C'
                            // },
                            legend: {
                                layout: 'vertical',
                                align: 'right',
                                verticalAlign: 'middle',
                                borderWidth: 0
                            },
                            series: [{
                                name: 'Placebo',
                                data: [null,-0.32,-0.6,-0.7,-0.8,null,-0.9,null,-1]
                            }, 
                             {
                                name: 'Citalopram',
                                data: [null,-0.33,-0.73,-0.9,-1,null,-1.2,null,-1.4]
                            },
                                                         {
                                name: 'Escitalopram',
                                data: [null,-0.5,-0.87,-1,-1.13,null,-1.4,null,-1.5]
                            },
                            ]
                        });
                    
                        $("#container2 .highcharts-container").css("height","500px");
                        




            break;


            case"#/chart3":
                





                        $('#container3').highcharts({
            chart: {
                backgroundColor: null,
                type: 'bar'
            },
            title: {
                text: 'Probabilité de figurer parmi les 4 antidépresseurs <br> les plus efficaces (taux de réponse)(1)'
            },
            // subtitle: {
            //     text: 'Source: Wikipedia.org'
            // },
            xAxis: {
                categories: ['mirtazapine','escaitalopram','venlafixine','sertraline','citalopra','milnacipran','bupropion','duloxetine','fluvoxamine','paroxetine','fluoxetine','reboxetine'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Porcentage %',
                    align: 'high'
                },
                labels: {
                    overflow: 'justify'
                }
            },
            tooltip: {
                valueSuffix: ' %'
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                // layout: 'vertical',
                // align: 'right',
                // verticalAlign: 'top',
                // x: -40,
                // y: 100,
                // floating: true,
                // borderWidth: 1,
                // backgroundColor: '#FFFFFF',
                // shadow: true,
                enabled:false
            },
            credits: {
                enabled: false
            },
            series: [{
                name: 'taux de réponse',
                data: [26,24,22,21,4,4,2,1,0,0]
            },
            //  {
            //     name: 'Year 1900',
            //     data: [133, 156, 947, 408, 6]
            // }, {
            //     name: 'Year 2008',
            //     data: [973, 914, 4054, 732, 34]
            // }
            ]
        });


            break;
            case '#/anim':

            $(".h1,.h2,.databox").removeClass("bounceIn animated");
            $(".h1,.h2,.databox").addClass("bounceIn animated");

            break;



        }
    });



$('#play').click(function () {
   
   $('#anim2').css('background-image','url("img/Seroplex-2.gif?'+ new Date().getTime()+'")'); 
});


$('.next').click(function () {
    console.log("Next");
    impress().next();
});
$('.prev').click(function () {
    console.log("Prev");
    impress().prev();
});

